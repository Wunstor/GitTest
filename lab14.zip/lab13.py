# Глобальная константа с тарифом за километр
TARIFF = 5.5  # ₽ за километр

# Функция без параметров для вывода приветствия
def show_header():
    print("=== Система расчёта маршрутов автобусов ===")

# Функция с параметрами и локальными переменными, возвращающая расстояние
def get_distance(x1, y1, x2, y2):
    dx = x2 - x1  # Локальная переменная
    dy = y2 - y1  # Локальная переменная
    return (dx ** 2 + dy ** 2) ** 0.5

# Функция, использующая глобальную константу TARIFF для расчёта стоимости
def calculate_cost(distance):
    # Используем глобальную константу TARIFF
    cost = distance * TARIFF
    return cost

# Функция, возвращающая несколько значений — расстояние и стоимость
def analyze_route(x1, y1, x2, y2):
    distance = get_distance(x1, y1, x2, y2)
    cost = calculate_cost(distance)
    return distance, cost  # Возвращаем два значения

# Дополнительная функция: проверка, является ли маршрут длинным Чернышев
def is_long_route(distance):
    """
    Возвращает True, если расстояние больше 10 км.
    
    Аргументы:
        distance (float): расстояние в километрах
    
    Возвращает:
        bool: True если расстояние > 10 км, иначе False
    """
    return distance > 10

# Дополнительная функция: сравнение двух маршрутов Лапин
def compare_routes(d1, d2):
    """
    Возвращает больший маршрут из двух.
    
    Аргументы:
        d1 (float): расстояние первого маршрута
        d2 (float): расстояние второго маршрута
    
    Возвращает:
        float: большее расстояние из двух
    """
    if d1 > d2:
        return d1
    else:
        return d2

# Дополнительная функция для демонстрации работы новых функций
def analyze_multiple_routes():
    """
    Демонстрирует работу дополнительных функций is_long_route и compare_routes
    """
    print("\n--- Анализ нескольких маршрутов ---")
    
    # Запрашиваем координаты для двух маршрутов
    print("Первый маршрут:")
    x1_1, y1_1 = map(float, input("Начальная остановка (x, y): ").split())
    x2_1, y2_1 = map(float, input("Конечная остановка (x, y): ").split())
    
    print("\nВторой маршрут:")
    x1_2, y1_2 = map(float, input("Начальная остановка (x, y): ").split())
    x2_2, y2_2 = map(float, input("Конечная остановка (x, y): ").split())
    
    # Вычисляем расстояния
    distance1 = get_distance(x1_1, y1_1, x2_1, y2_1)
    distance2 = get_distance(x1_2, y1_2, x2_2, y2_2)
    
    # Используем функцию is_long_route для проверки
    print(f"\nРезультаты анализа:")
    print(f"Маршрут 1: {distance1:.1f} км")
    print(f"  Длинный маршрут (>10 км)? {'Да' if is_long_route(distance1) else 'Нет'}")
    print(f"  Стоимость: {calculate_cost(distance1):.1f} ₽")
    
    print(f"Маршрут 2: {distance2:.1f} км")
    print(f"  Длинный маршрут (>10 км)? {'Да' if is_long_route(distance2) else 'Нет'}")
    print(f"  Стоимость: {calculate_cost(distance2):.1f} ₽")
    
    # Используем функцию compare_routes для сравнения
    longer_route = compare_routes(distance1, distance2)
    print(f"\nБолее длинный маршрут: {longer_route:.1f} км")

# Главная часть программы
def main():
    # Вызываем show_header()
    show_header()
    
    print("1. Анализ одного маршрута")
    print("2. Сравнение двух маршрутов")
    choice = input("Выберите опцию (1 или 2): ")
    
    if choice == "1":
        # Анализ одного маршрута
        x1, y1 = map(float, input("Введите координаты первой остановки (x1, y1): ").split())
        x2, y2 = map(float, input("Введите координаты второй остановки (x2, y2): ").split())
        
        # Вызываем функцию analyze_route() и получаем два значения
        distance, cost = analyze_route(x1, y1, x2, y2)
        
        # Выводим расстояние и примерную стоимость поездки
        print(f"\nРезультаты:")
        print(f"Расстояние между остановками: {distance:.1f} км")
        print(f"Примерная стоимость маршрута: {cost:.1f} ₽")
        
        # Проверяем, является ли маршрут длинным
        if is_long_route(distance):
            print("Это длинный маршрут (более 10 км)")
        else:
            print("Это не длинный маршрут (10 км или меньше)")
            
    elif choice == "2":
        # Анализ и сравнение двух маршрутов
        analyze_multiple_routes()
    else:
        print("Некорректный выбор. Завершение программы.")

# Запуск программы
if __name__ == "__main__":
    main()
